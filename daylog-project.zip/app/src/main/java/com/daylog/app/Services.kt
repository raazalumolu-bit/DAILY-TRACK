package com.daylog.app

import android.app.Notification
import android.app.Service
import android.content.BroadcastReceiver
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.media.AudioManager
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationResult
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority

class TrackerService : Service(), SensorEventListener {
    private lateinit var fused: FusedLocationProviderClient
    private val handler = Handler(Looper.getMainLooper())
    private var started = false

    private val callback = object : LocationCallback() {
        override fun onLocationResult(result: LocationResult) {
            val db = Db.get(applicationContext)
            for (l in result.locations) {
                if (l.accuracy > 150f) continue
                val cv = ContentValues()
                cv.put("t", l.time)
                cv.put("lat", l.latitude)
                cv.put("lng", l.longitude)
                cv.put("acc", l.accuracy.toDouble())
                db.insert("loc", null, cv)
                P.put(applicationContext, "last_lat", l.latitude.toString())
                P.put(applicationContext, "last_lng", l.longitude.toString())
                // live location push every 5 min
                val now = System.currentTimeMillis()
                if (now - P.l(applicationContext, "live_pushed", 0L) >= 5 * 60000L) {
                    P.putL(applicationContext, "live_pushed", now)
                    val lat2 = l.latitude; val lng2 = l.longitude; val acc2 = l.accuracy.toDouble()
                    Thread { try { Cloud.uploadLive(applicationContext, lat2, lng2, acc2) } catch (e: Exception) {} }.start()
                }
            }
        }
    }

    private val syncLoop = object : Runnable {
        override fun run() {
            val ctx = applicationContext
            Thread { try { Sync.run(ctx, true) } catch (e: Exception) {} }.start()
            handler.postDelayed(this, 30 * 60000L)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Notif.channels(this)
        val n = Notif.persistent(this, "Day Log running", "Tracking location, calls, messages. Device: ${Device.name(this)}")
        try {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION)
        } catch (e: Exception) { stopSelf(); return START_NOT_STICKY }
        if (!started) {
            started = true
            fused = LocationServices.getFusedLocationProviderClient(this)
            try {
                val req = LocationRequest.Builder(Priority.PRIORITY_BALANCED_POWER_ACCURACY, 180000L)
                    .setMinUpdateIntervalMillis(120000L).build()
                fused.requestLocationUpdates(req, callback, Looper.getMainLooper())
            } catch (e: SecurityException) { stopSelf(); return START_NOT_STICKY }
            val sm = getSystemService(Context.SENSOR_SERVICE) as SensorManager
            val step = sm.getDefaultSensor(Sensor.TYPE_STEP_COUNTER)
            if (step != null) sm.registerListener(this, step, SensorManager.SENSOR_DELAY_NORMAL, 60000000)
            handler.postDelayed(syncLoop, 120000L)
        }
        return START_STICKY
    }

    override fun onSensorChanged(event: SensorEvent?) {
        if (event == null || event.values.isEmpty()) return
        Steps.record(applicationContext, event.values[0].toLong())
    }
    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
    override fun onDestroy() {
        try { fused.removeLocationUpdates(callback) } catch (e: Exception) {}
        try { (getSystemService(Context.SENSOR_SERVICE) as SensorManager).unregisterListener(this) } catch (e: Exception) {}
        handler.removeCallbacks(syncLoop)
        super.onDestroy()
    }
}

class NotifCapture : NotificationListenerService() {
    private val skip = setOf("android","com.android.systemui","com.samsung.android.incallui",
        "com.android.providers.downloads","com.sec.android.app.launcher")

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn == null) return
        try {
            val pkg = sbn.packageName ?: return
            if (pkg == packageName || skip.contains(pkg)) return
            val n = sbn.notification ?: return
            if ((n.flags and Notification.FLAG_ONGOING_EVENT) != 0) return
            if ((n.flags and Notification.FLAG_GROUP_SUMMARY) != 0) return
            val ex = n.extras ?: return
            val title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
            val body = (ex.getCharSequence(Notification.EXTRA_BIG_TEXT) ?: ex.getCharSequence(Notification.EXTRA_TEXT))?.toString() ?: ""
            if (title.isBlank() && body.isBlank()) return
            val low = (title + " " + body).lowercase()
            if (low.contains("otp") || low.contains("one time") || low.contains("verification code")) return
            val db = Db.get(applicationContext)
            val now = System.currentTimeMillis()
            val dup = db.rawQuery("SELECT 1 FROM notif WHERE pkg=? AND title=? AND body=? AND t>?",
                arrayOf(pkg, title, body, (now - 60000L).toString()))
            val isDup = dup.moveToFirst(); dup.close()
            if (isDup) return
            val label = try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg,0)).toString() } catch (e: Exception) { pkg }
            val grp = if (Classify.MSG.containsKey(pkg)) Classify.forPerson(applicationContext, title, body) else "Other"
            val cv = ContentValues()
            cv.put("t", now); cv.put("pkg", pkg); cv.put("app", label)
            cv.put("title", title); cv.put("body", body.take(300)); cv.put("grp", grp)
            db.insert("notif", null, cv)
        } catch (e: Exception) {}
    }
}

class ConversationService : Service() {
    private var sr: SpeechRecognizer? = null
    private val handler = Handler(Looper.getMainLooper())
    private var running = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Notif.channels(this)
        val n = Notif.persistent(this, "Listening to conversations", "Speech → text (no audio saved). Tap to open.")
        try {
            startForeground(2, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } catch (e: Exception) { P.putB(this, "talking", false); stopSelf(); return START_NOT_STICKY }
        if (!running) { running = true; P.putB(this, "talking", true); muteBeep(true); listen() }
        return START_STICKY
    }

    private fun muteBeep(mute: Boolean) {
        try {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            am.adjustStreamVolume(AudioManager.STREAM_NOTIFICATION, if (mute) AudioManager.ADJUST_MUTE else AudioManager.ADJUST_UNMUTE, 0)
        } catch (e: Exception) {}
    }

    private fun listen() {
        if (!running) return
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { P.putB(this, "talking", false); stopSelf(); return }
        try { sr?.destroy() } catch (e: Exception) {}
        val r = SpeechRecognizer.createSpeechRecognizer(this); sr = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(p: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(b: Bundle?) {}
            override fun onEvent(t: Int, p: Bundle?) {}
            override fun onError(error: Int) {
                if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) { P.putB(this@ConversationService,"talking",false); stopSelf(); return }
                handler.postDelayed({ listen() }, if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 1500L else 700L)
            }
            override fun onResults(results: Bundle?) {
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: ""
                if (text.isNotBlank()) {
                    val forced = P.s(this@ConversationService, "talk_group", "Auto")
                    val grp = if (forced == "Auto") Classify.forText(text) else forced
                    val cv = ContentValues(); cv.put("t", System.currentTimeMillis()); cv.put("body", text); cv.put("grp", grp)
                    Db.get(applicationContext).insert("talk", null, cv)
                }
                handler.postDelayed({ listen() }, 400L)
            }
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, P.s(this, "talk_lang", "te-IN"))
        i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        try { r.startListening(i) } catch (e: Exception) { handler.postDelayed({ listen() }, 2000L) }
    }

    override fun onDestroy() {
        running = false; handler.removeCallbacksAndMessages(null)
        try { sr?.destroy() } catch (e: Exception) {}
        muteBeep(false); P.putB(this, "talking", false); super.onDestroy()
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action != Intent.ACTION_BOOT_COMPLETED) return
        Sched.daily(context)
        if (P.b(context, "tracking", false)) {
            try { Notif.channels(context); context.startForegroundService(Intent(context, TrackerService::class.java)) } catch (e: Exception) {}
        }
    }
}

class ReportReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val pending = goAsync()
        Thread {
            try { Deliver.dailyReport(context.applicationContext) } catch (e: Exception) {}
            try { Sched.daily(context.applicationContext) } catch (e: Exception) {}
            pending.finish()
        }.start()
    }
}
