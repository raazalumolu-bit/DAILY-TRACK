package com.daylog.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.MediaStore
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private val fields = LinkedHashMap<String, EditText>()
    private val ui = Handler(Looper.getMainLooper())
    private var reportView: TextView? = null
    private var built: Built? = null
    private var camUri: Uri? = null

    private val perms = arrayOf(
        Manifest.permission.ACCESS_FINE_LOCATION,
        Manifest.permission.ACCESS_COARSE_LOCATION,
        Manifest.permission.RECORD_AUDIO,
        Manifest.permission.READ_CALL_LOG,
        Manifest.permission.READ_CONTACTS,
        Manifest.permission.READ_SMS,
        Manifest.permission.ACTIVITY_RECOGNITION,
        Manifest.permission.POST_NOTIFICATIONS
    )

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        Notif.channels(this)
        Device.id(this) // generate device_id on first launch
        val sv = ScrollView(this)
        sv.setBackgroundColor(Color.parseColor("#EDF1F4"))
        root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(14), dp(34), dp(14), dp(48))
        sv.addView(root)
        setContentView(sv)
        build()
    }

    override fun onResume() { super.onResume(); build() }
    override fun onPause() { saveFields(); super.onPause() }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun has(p: String) = checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED
    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_LONG).show()

    private fun text(t: String, size: Float = 15f, bold: Boolean = false, color: String = "#16202E"): TextView {
        val v = TextView(this); v.text = t; v.textSize = size
        v.setTextColor(Color.parseColor(color))
        if (bold) v.setTypeface(null, Typeface.BOLD)
        v.setPadding(0, dp(3), 0, dp(3)); return v
    }

    private fun button(t: String, onClick: () -> Unit): Button {
        val b = Button(this); b.text = t; b.isAllCaps = false; b.setOnClickListener { onClick() }; return b
    }

    private fun card(title: String): LinearLayout {
        val c = LinearLayout(this); c.orientation = LinearLayout.VERTICAL
        val bg = GradientDrawable(); bg.setColor(Color.WHITE); bg.cornerRadius = dp(16).toFloat()
        bg.setStroke(dp(1), Color.parseColor("#D6DEE6")); c.background = bg
        c.setPadding(dp(14), dp(12), dp(14), dp(12))
        val lp = LinearLayout.LayoutParams(-1, -2); lp.setMargins(0, 0, 0, dp(12)); c.layoutParams = lp
        c.addView(text(title, 18f, true)); root.addView(c); return c
    }

    private fun field(parent: LinearLayout, key: String, label: String, hint: String, secret: Boolean = false) {
        parent.addView(text(label, 13f, false, "#576476"))
        val e = EditText(this); e.hint = hint; e.setText(P.s(this, key)); e.setSingleLine(true)
        if (secret) e.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        parent.addView(e); fields[key] = e
    }

    private fun saveFields() { for ((k, v) in fields) P.put(this, k, v.text.toString().trim()) }

    private fun statusLine(parent: LinearLayout, ok: Boolean, label: String) {
        parent.addView(text((if (ok) "✓  " else "✗  ") + label, 15f, false, if (ok) "#0C8A70" else "#C93A2B"))
    }

    private fun build() {
        root.removeAllViews(); fields.clear()
        root.addView(text("Day Log", 30f, true))
        root.addView(text("Automatic daily tracker — Samsung S22", 14f, false, "#576476"))

        // === SETUP ===
        val setup = card("1. Permissions")
        statusLine(setup, has(Manifest.permission.ACCESS_FINE_LOCATION), "Location (fine)")
        statusLine(setup, has(Manifest.permission.ACCESS_BACKGROUND_LOCATION), "Location — all the time")
        statusLine(setup, has(Manifest.permission.READ_CALL_LOG), "Call log")
        statusLine(setup, has(Manifest.permission.READ_SMS), "SMS (for UPI transactions)")
        statusLine(setup, has(Manifest.permission.RECORD_AUDIO), "Microphone")
        statusLine(setup, has(Manifest.permission.ACTIVITY_RECOGNITION), "Steps")
        val nlOk = (Settings.Secure.getString(contentResolver,"enabled_notification_listeners") ?: "").contains(packageName)
        statusLine(setup, nlOk, "Notification access (WhatsApp, messages)")
        statusLine(setup, Sync.hasUsageAccess(this), "Usage access (app screen time)")
        statusLine(setup, (getSystemService(Context.POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(packageName), "Battery unrestricted")
        setup.addView(button("Allow all permissions") { askPerms() })
        setup.addView(button("Notification access") { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) })
        setup.addView(button("Usage access") { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) })
        setup.addView(button("Battery unrestricted") {
            try { val i = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS); i.data = Uri.parse("package:$packageName"); startActivity(i) }
            catch (e: Exception) { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }
        })
        setup.addView(button("App info (Restricted settings)") {
            val i = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS); i.data = Uri.parse("package:$packageName"); startActivity(i)
        })
        setup.addView(text("Samsung: If Notification access is greyed out → App info → three dots top right → Allow restricted settings, then try again.", 13f, false, "#576476"))
        setup.addView(text("Samsung battery: Settings → Battery → Background limits → Never sleeping apps → add Day Log.", 13f, false, "#576476"))

        // === DEVICE ===
        val devCard = card("2. This Device")
        val devId = Device.id(this)
        val devName = Device.name(this)
        devCard.addView(text("Device ID: $devId", 13f, false, "#576476"))
        devCard.addView(text("Name shown in dashboard: $devName", 14f, true))
        field(devCard, "device_name", "Set a name for this phone", "e.g. My Samsung S22, Phone 1, Ravi's Phone")
        devCard.addView(button("Save device name") { saveFields(); toast("Device name saved. Restart tracking to apply.") })
        devCard.addView(text("Install the same APK on your second phone. It will get its own Device ID automatically. Both appear separately in the web dashboard.", 13f, false, "#576476"))

        // === TRACKING ===
        val tr = card("3. Tracking")
        val on = P.b(this, "tracking", false)
        tr.addView(text(if (on) "Tracking is ON" else "Tracking is OFF", 15f, true, if (on) "#0C8A70" else "#C93A2B"))
        tr.addView(button(if (on) "Stop tracking" else "Start tracking") {
            if (on) { stopService(Intent(this, TrackerService::class.java)); P.putB(this, "tracking", false) }
            else if (!has(Manifest.permission.ACCESS_FINE_LOCATION)) toast("Allow location first")
            else { P.putB(this, "tracking", true); startForegroundService(Intent(this, TrackerService::class.java)); Sched.daily(this) }
            build()
        })
        tr.addView(text("Set your home and work locations so time is counted correctly:", 14f, false, "#576476"))
        tr.addView(button("I am at HOME now") { savePlace("Home", "home") })
        tr.addView(button("I am at WORK / SHOP now") { savePlace("Work", "work") })
        tr.addView(button("Save custom place name") { askPlaceName() })

        // === REPORT ===
        val rp = card("4. Today's Report")
        rp.addView(button("Build & upload report") { buildReport() })
        rp.addView(button("Send to WhatsApp") {
            val b = built ?: run { toast("Build the report first"); return@button }
            try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(Wa.url(this, b.short.take(1800))))) }
            catch (e: Exception) { toast("Could not open WhatsApp") }
        })
        rp.addView(button("Copy report text") {
            val b = built ?: run { toast("Build the report first"); return@button }
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("report", b.text)); toast("Copied!")
        })
        val rv = text(P.s(this, "last_report", "No report yet. Tap Build & upload report."), 14f)
        rv.setTextIsSelectable(true); rp.addView(rv); reportView = rv

        // === UPI ===
        val upCard = card("5. UPI Transactions (today)")
        if (!has(Manifest.permission.READ_SMS)) {
            upCard.addView(text("Allow SMS permission above to see UPI transactions automatically.", 14f, false, "#576476"))
        } else {
            val db = Db.get(this)
            val today = U.today()
            val s2 = U.dayStart(today); val e2 = s2 + 86400000L
            val cur = db.rawQuery("SELECT t,amount,type,merchant FROM upi WHERE t>=? AND t<?",
                arrayOf(s2.toString(), e2.toString()))
            if (!cur.moveToFirst()) {
                upCard.addView(text("No UPI transactions found today. SMS read happens every 30 min.", 14f, false, "#576476"))
            } else {
                var credit = 0.0; var debit = 0.0; var cnt = 0
                cur.moveToFirst()
                do {
                    val amt = cur.getDouble(1); val type = cur.getString(2)
                    if (type == "Credit") credit += amt else debit += amt
                    cnt++
                    val row = LinearLayout(this); row.orientation = LinearLayout.HORIZONTAL
                    row.setPadding(0, dp(4), 0, dp(4))
                    val tp = text(U.hm(cur.getLong(0)) + "  " + type, 14f, false, if (type=="Credit") "#0C8A70" else "#C93A2B")
                    val am = text("Rs ${cur.getDouble(1).toInt()}", 14f, true, "#16202E")
                    val me = text("  " + cur.getString(3), 14f, false, "#576476")
                    row.addView(tp); row.addView(am); row.addView(me)
                    upCard.addView(row)
                } while (cur.moveToNext())
                cur.close()
                upCard.addView(text("\nTotal $cnt transactions: +Rs ${credit.toInt()} received, -Rs ${debit.toInt()} paid", 14f, true))
            }
            cur.close()
            upCard.addView(button("Sync UPI now") {
                Thread { try { Upi.sync(this); ui.post { build() } } catch (e: Exception) {} }.start()
            })
        }

        // === PEOPLE ===
        val pe = card("6. Family, Friends, Official")
        pe.addView(text("App guesses group from name and message words. Tap to correct, it remembers.", 14f, false, "#576476"))
        pe.addView(button("Who is who? (correct groups)") { people() })

        // === CONVERSATION ===
        val cv = card("7. Conversations (optional mic)")
        val talking = P.b(this, "talking", false)
        cv.addView(text(if (talking) "Listening is ON — speech saved as text only" else "Listening is OFF", 14f, true, if (talking) "#0C8A70" else "#576476"))
        cv.addView(button(if (talking) "Stop listening" else "Start listening") {
            if (talking) { stopService(Intent(this, ConversationService::class.java)); P.putB(this, "talking", false) }
            else if (!has(Manifest.permission.RECORD_AUDIO)) toast("Allow microphone first")
            else startForegroundService(Intent(this, ConversationService::class.java))
            ui.postDelayed({ build() }, 600L)
        })
        val langs = listOf("te-IN", "en-IN", "hi-IN")
        val lnames = mapOf("te-IN" to "Telugu", "en-IN" to "English", "hi-IN" to "Hindi")
        val curL = P.s(this, "talk_lang", "te-IN")
        cv.addView(button("Language: " + (lnames[curL] ?: curL) + " — tap to change") {
            P.put(this, "talk_lang", langs[(langs.indexOf(curL)+1) % langs.size]); build()
        })
        val curG = P.s(this, "talk_group", "Auto")
        val gList = listOf("Auto","Family","Friends","Official")
        cv.addView(button("Talking with: $curG — tap to change") {
            P.put(this, "talk_group", gList[(gList.indexOf(curG)+1) % gList.size]); build()
        })

        // === CAMERA ===
        val cm = card("8. Camera")
        cm.addView(button("Take photo (receipt, visiting card, document)") { takePhoto() })

        // === SETTINGS ===
        val st = card("9. WhatsApp, Dashboard & AI")
        field(st, "wa_phone", "Your WhatsApp number (with country code)", "919876543210")
        field(st, "report_time", "Daily report time (24-hour format)", "21:30")
        st.addView(text("Dashboard (Supabase):", 13f, true, "#576476"))
        field(st, "sb_url", "Supabase project URL", "https://eigzfjowkoibftmckbpw.supabase.co")
        field(st, "sb_anon", "Supabase publishable key", "", true)
        field(st, "sb_secret", "Your secret word (same in all phones)", "", true)
        st.addView(text("Auto WhatsApp (optional — CallMeBot):", 13f, true, "#576476"))
        field(st, "cmb_key", "CallMeBot API key", "", true)
        st.addView(text("AI summary (optional):", 13f, true, "#576476"))
        field(st, "ai_key", "Claude API key", "", true)
        st.addView(button("Save settings") { saveFields(); Sched.daily(this); toast("Saved!") })
        st.addView(button("Test upload now") {
            saveFields()
            Toast.makeText(this, "Uploading...", Toast.LENGTH_SHORT).show()
            Thread {
                val b = try { Report.build(applicationContext, U.today()) } catch (e: Exception) { ui.post { toast("Build failed: ${e.message}") }; return@Thread }
                val m = Cloud.put(applicationContext, U.today(), b.json)
                ui.post { toast(m) }
            }.start()
        })
        st.addView(text("Web dashboard: https://<username>.github.io/<repo>/ — enter same URL, key, secret word.", 13f, false, "#576476"))
        st.addView(text("Device ID for this phone: ${Device.id(this)}", 13f, false, "#576476"))
    }

    private fun askPerms() {
        val need = perms.filter { !has(it) }
        if (need.isNotEmpty()) requestPermissions(need.toTypedArray(), 1) else askBg()
    }

    private fun askBg() {
        if (has(Manifest.permission.ACCESS_FINE_LOCATION) && !has(Manifest.permission.ACCESS_BACKGROUND_LOCATION)) {
            toast("Next screen: choose Allow all the time for location")
            requestPermissions(arrayOf(Manifest.permission.ACCESS_BACKGROUND_LOCATION), 2)
        } else build()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 1) askBg() else build()
    }

    private fun savePlace(name: String, kind: String) {
        if (!has(Manifest.permission.ACCESS_FINE_LOCATION)) { toast("Allow location first"); return }
        toast("Getting location...")
        try {
            LocationServices.getFusedLocationProviderClient(this)
                .getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, null)
                .addOnSuccessListener { loc ->
                    if (loc == null) toast("Could not get location. Turn on GPS and try again.")
                    else {
                        val db = Db.get(this)
                        if (kind != "other") db.execSQL("DELETE FROM places WHERE kind=?", arrayOf(kind))
                        val cv = ContentValues(); cv.put("name", name); cv.put("kind", kind)
                        cv.put("lat", loc.latitude); cv.put("lng", loc.longitude)
                        db.insert("places", null, cv); toast("$name saved!")
                    }
                }.addOnFailureListener { toast("Could not get location") }
        } catch (e: SecurityException) { toast("Allow location first") }
    }

    private fun askPlaceName() {
        val input = EditText(this); input.hint = "e.g. Supplier, Temple, Gym"
        AlertDialog.Builder(this).setTitle("Name this place").setView(input)
            .setPositiveButton("Save") { _, _ -> val n = input.text.toString().trim(); if (n.isNotEmpty()) savePlace(n, "other") }
            .setNegativeButton("Cancel", null).show()
    }

    private fun buildReport() {
        reportView?.text = "Building..."
        val app = applicationContext
        Thread {
            try {
                Sync.run(app, false)
                val b = Report.build(app, U.today())
                P.put(app, "last_report", b.text)
                val m = Cloud.put(app, U.today(), b.json)
                ui.post { built = b; reportView?.text = b.text + "\n\n--- $m ---" }
            } catch (e: Exception) { ui.post { reportView?.text = "Error: ${e.message}" } }
        }.start()
    }

    private fun people() {
        val db = Db.get(this)
        val names = LinkedHashSet<String>()
        val since = (System.currentTimeMillis() - 30L * 86400000L).toString()
        var cur = db.rawQuery("SELECT DISTINCT name FROM calls WHERE t>? AND name<>'' ORDER BY t DESC LIMIT 60", arrayOf(since))
        while (cur.moveToNext()) names.add(cur.getString(0) ?: ""); cur.close()
        val keys = Classify.MSG.keys.joinToString(",") { "'$it'" }
        cur = db.rawQuery("SELECT DISTINCT title FROM notif WHERE t>? AND pkg IN ($keys) AND title<>'' ORDER BY t DESC LIMIT 60", arrayOf(since))
        while (cur.moveToNext()) names.add(cur.getString(0) ?: ""); cur.close()
        names.remove("")
        val list = LinearLayout(this); list.orientation = LinearLayout.VERTICAL; list.setPadding(dp(10),dp(6),dp(10),dp(6))
        if (names.isEmpty()) list.addView(text("No calls or messages captured yet.", 14f))
        val cycle = listOf("Family","Friends","Official","Other")
        for (n in names) {
            val b = Button(this); b.isAllCaps = false; b.gravity = Gravity.START or Gravity.CENTER_VERTICAL
            var g = Classify.forName(this, n) ?: "Other"; b.text = "$n  →  $g"
            b.setOnClickListener {
                g = cycle[(cycle.indexOf(g)+1) % cycle.size]
                db.execSQL("INSERT OR REPLACE INTO grp_override(name,grp) VALUES(?,?)", arrayOf(n, g))
                db.execSQL("UPDATE calls SET grp=? WHERE name=?", arrayOf(g, n))
                db.execSQL("UPDATE notif SET grp=? WHERE title=?", arrayOf(g, n))
                b.text = "$n  →  $g"
            }
            list.addView(b)
        }
        val sv = ScrollView(this); sv.addView(list)
        AlertDialog.Builder(this).setTitle("Tap name to change group").setView(sv).setPositiveButton("Done", null).show()
    }

    private fun takePhoto() {
        try {
            val cv = ContentValues()
            cv.put(MediaStore.Images.Media.DISPLAY_NAME, "daylog_${System.currentTimeMillis()}.jpg")
            cv.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv) ?: run { toast("Could not prepare photo"); return }
            camUri = uri
            val i = Intent(MediaStore.ACTION_IMAGE_CAPTURE); i.putExtra(MediaStore.EXTRA_OUTPUT, uri)
            startActivityForResult(i, 10)
        } catch (e: Exception) { toast("Could not open camera") }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 10) {
            val u = camUri
            if (resultCode == RESULT_OK && u != null) {
                val cv = ContentValues(); cv.put("t", System.currentTimeMillis())
                cv.put("uri", u.toString())
                cv.put("lat", P.s(this,"last_lat","0").toDoubleOrNull() ?: 0.0)
                cv.put("lng", P.s(this,"last_lng","0").toDoubleOrNull() ?: 0.0)
                Db.get(this).insert("photos", null, cv); toast("Photo saved to Gallery")
            } else if (u != null) { try { contentResolver.delete(u, null, null) } catch (e: Exception) {} }
        }
    }
}
