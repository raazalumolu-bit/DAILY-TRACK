package com.daylog.app

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.graphics.drawable.Icon
import android.location.Geocoder
import android.net.Uri
import android.provider.CallLog
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.asin
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

/* ---------------- preferences ---------------- */
object P {
    fun sp(c: Context): SharedPreferences =
        c.applicationContext.getSharedPreferences("daylog", Context.MODE_PRIVATE)

    fun s(c: Context, k: String, d: String = ""): String = sp(c).getString(k, d) ?: d
    fun put(c: Context, k: String, v: String) { sp(c).edit().putString(k, v).apply() }
    fun b(c: Context, k: String, d: Boolean = false): Boolean = sp(c).getBoolean(k, d)
    fun putB(c: Context, k: String, v: Boolean) { sp(c).edit().putBoolean(k, v).apply() }
    fun l(c: Context, k: String, d: Long = 0L): Long = sp(c).getLong(k, d)
    fun putL(c: Context, k: String, v: Long) { sp(c).edit().putLong(k, v).apply() }
}

/* ---------------- small utilities ---------------- */
object U {
    fun day(t: Long): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(t))
    fun today(): String = day(System.currentTimeMillis())
    fun dayStart(d: String): Long = SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(d)!!.time
    fun hm(t: Long): String = SimpleDateFormat("h:mm a", Locale.US).format(Date(t))
    fun dur(min: Int): String = if (min >= 60) "${min / 60}h ${min % 60}m" else "${min}m"
    fun enc(s: String): String = URLEncoder.encode(s, "UTF-8")

    fun dist(lat1: Double, lng1: Double, lat2: Double, lng2: Double): Double {
        val r = 6371000.0
        val p1 = Math.toRadians(lat1)
        val p2 = Math.toRadians(lat2)
        val dp = p2 - p1
        val dl = Math.toRadians(lng2 - lng1)
        val x = sin(dp / 2).pow(2) + cos(p1) * cos(p2) * sin(dl / 2).pow(2)
        return 2 * r * asin(min(1.0, sqrt(x)))
    }
}

/* ---------------- database ---------------- */
class Db private constructor(ctx: Context) : SQLiteOpenHelper(ctx, "daylog.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE loc(id INTEGER PRIMARY KEY AUTOINCREMENT, t INTEGER, lat REAL, lng REAL, acc REAL)")
        db.execSQL("CREATE INDEX loc_t ON loc(t)")
        db.execSQL("CREATE TABLE places(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, kind TEXT, lat REAL, lng REAL)")
        db.execSQL("CREATE TABLE notif(id INTEGER PRIMARY KEY AUTOINCREMENT, t INTEGER, pkg TEXT, app TEXT, title TEXT, body TEXT, grp TEXT)")
        db.execSQL("CREATE INDEX notif_t ON notif(t)")
        db.execSQL("CREATE TABLE calls(id INTEGER PRIMARY KEY AUTOINCREMENT, t INTEGER, number TEXT, name TEXT, dur INTEGER, type INTEGER, grp TEXT, UNIQUE(t, number))")
        db.execSQL("CREATE TABLE talk(id INTEGER PRIMARY KEY AUTOINCREMENT, t INTEGER, body TEXT, grp TEXT)")
        db.execSQL("CREATE TABLE usage(day TEXT, pkg TEXT, app TEXT, ms INTEGER, PRIMARY KEY(day, pkg))")
        db.execSQL("CREATE TABLE photos(id INTEGER PRIMARY KEY AUTOINCREMENT, t INTEGER, uri TEXT, lat REAL, lng REAL)")
        db.execSQL("CREATE TABLE grp_override(name TEXT PRIMARY KEY, grp TEXT)")
        db.execSQL("CREATE TABLE geo_cache(k TEXT PRIMARY KEY, name TEXT)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}

    companion object {
        @Volatile
        private var inst: Db? = null

        fun get(c: Context): SQLiteDatabase {
            val existing = inst
            if (existing != null) return existing.writableDatabase
            synchronized(this) {
                val again = inst
                if (again != null) return again.writableDatabase
                val created = Db(c.applicationContext)
                inst = created
                return created.writableDatabase
            }
        }
    }
}

/* ---------------- who is family / friends / official ---------------- */
object Classify {
    val MSG: Map<String, String> = mapOf(
        "com.whatsapp" to "WhatsApp",
        "com.whatsapp.w4b" to "WhatsApp Business",
        "org.telegram.messenger" to "Telegram",
        "com.google.android.apps.messaging" to "Messages",
        "com.samsung.android.messaging" to "Messages",
        "com.instagram.android" to "Instagram",
        "com.facebook.orca" to "Messenger",
        "com.google.android.gm" to "Gmail"
    )

    private val FAM_NAME = setOf(
        "amma", "mom", "mummy", "mother", "nanna", "dad", "daddy", "papa", "appa", "father",
        "anna", "akka", "tammudu", "chelli", "wife", "husband", "son", "daughter", "uncle",
        "aunty", "aunt", "mama", "athayya", "attayya", "babai", "pinni", "bava", "vadina",
        "thatha", "nanamma", "ammamma", "bhabhi", "sister", "brother", "family", "home"
    )
    private val OFF_NAME = setOf(
        "sir", "madam", "mam", "manager", "office", "hr", "boss", "bank", "dealer", "supplier",
        "distributor", "customer", "shop", "service", "care", "agent", "gm", "dm", "team",
        "accounts", "sales", "support", "client"
    )
    private val FAM_TXT = listOf(
        "amma", "nanna", "pelli", "function", "intiki", "illu", "pillalu", "school", "fees",
        "dinner", "tiffin", "bhojanam", "hospital", "birthday", "festival", "ఇల్లు", "అమ్మ",
        "నాన్న", "పిల్లలు", "పండుగ"
    )
    private val OFF_TXT = listOf(
        "order", "stock", "bill", "invoice", "payment", "delivery", "customer", "meeting",
        "office", "dealer", "supplier", "gst", "sale", "quotation", "warranty", "repair", "offer",
        "target", "salary", "rate", "price", "boss", "client", "account", "emi", "ఆర్డర్",
        "బిల్లు", "పేమెంట్", "స్టాక్"
    )
    private val FRI_TXT = listOf(
        "bro", "macha", "party", "trip", "movie", "match", "cricket", "chai", "beer", "cinema",
        "dost", "lunch", "outing", "bike", "gym", "మామ", "సినిమా"
    )
    private val splitter = Regex("[^\\p{L}\\p{M}\\p{N}]+")

    private fun tokens(s: String): Set<String> =
        s.lowercase().split(splitter).filter { it.isNotEmpty() }.toSet()

    private fun score(text: String, words: List<String>): Int {
        val t = text.lowercase()
        val tk = tokens(text)
        var n = 0
        for (w in words) {
            if (tk.contains(w) || (w.length >= 5 && t.contains(w))) n++
        }
        return n
    }

    fun forText(text: String): String {
        val f = score(text, FAM_TXT)
        val o = score(text, OFF_TXT)
        val fr = score(text, FRI_TXT)
        val best = maxOf(f, o, fr)
        if (best == 0) return "Other"
        if (o == best) return "Official"
        if (f == best) return "Family"
        return "Friends"
    }

    fun forName(c: Context, name: String?): String? {
        if (name == null || name.isBlank()) return null
        val cur = Db.get(c).rawQuery("SELECT grp FROM grp_override WHERE lower(name)=lower(?)", arrayOf(name))
        var g: String? = null
        if (cur.moveToFirst()) g = cur.getString(0)
        cur.close()
        if (g != null) return g
        val tk = tokens(name)
        if (tk.any { FAM_NAME.contains(it) }) return "Family"
        if (tk.any { OFF_NAME.contains(it) }) return "Official"
        return null
    }

    fun forPerson(c: Context, name: String?, text: String): String =
        forName(c, name) ?: forText((name ?: "") + " " + text)
}

/* ---------------- network ---------------- */
object Net {
    fun call(method: String, url: String, headers: Map<String, String>, body: String?): Pair<Int, String> {
        val conn = URL(url).openConnection() as HttpURLConnection
        try {
            conn.requestMethod = method
            conn.connectTimeout = 15000
            conn.readTimeout = 60000
            for ((k, v) in headers) conn.setRequestProperty(k, v)
            if (body != null) {
                conn.doOutput = true
                conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            }
            val code = conn.responseCode
            val stream = if (code >= 400) conn.errorStream else conn.inputStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            return Pair(code, text)
        } finally {
            conn.disconnect()
        }
    }
}

object Cloud {
    fun configured(c: Context): Boolean =
        P.s(c, "sb_url").isNotBlank() && P.s(c, "sb_anon").isNotBlank() && P.s(c, "sb_secret").isNotBlank()

    fun put(c: Context, day: String, json: JSONObject): String {
        if (!configured(c)) return "Web dashboard is not set up yet"
        return try {
            val anon = P.s(c, "sb_anon").trim()
            val h = HashMap<String, String>()
            h["apikey"] = anon
            if (anon.startsWith("eyJ")) h["Authorization"] = "Bearer $anon"
            h["Content-Type"] = "application/json"
            val body = JSONObject()
                .put("p_key", P.s(c, "sb_secret").trim())
                .put("p_day", day)
                .put("p_report", json)
                .toString()
            val url = P.s(c, "sb_url").trim().trimEnd('/') + "/rest/v1/rpc/put_report"
            val r = Net.call("POST", url, h, body)
            if (r.first in 200..299) "Uploaded to web dashboard" else "Upload failed (${r.first}): ${r.second.take(150)}"
        } catch (e: Exception) {
            "Upload failed: ${e.message}"
        }
    }
}

object Wa {
    private fun digits(c: Context): String = P.s(c, "wa_phone").filter { it.isDigit() }

    fun url(c: Context, text: String): String = "https://wa.me/" + digits(c) + "?text=" + U.enc(text)

    fun auto(c: Context, text: String): String {
        val key = P.s(c, "cmb_key").trim()
        val d = digits(c)
        if (key.isBlank() || d.isBlank()) return "Automatic WhatsApp is not set up"
        return try {
            val u = "https://api.callmebot.com/whatsapp.php?phone=%2B" + d +
                "&text=" + U.enc(text.take(1500)) + "&apikey=" + U.enc(key)
            val r = Net.call("GET", u, HashMap(), null)
            if (r.first in 200..299) "Sent to WhatsApp" else "WhatsApp send failed (${r.first})"
        } catch (e: Exception) {
            "WhatsApp send failed: ${e.message}"
        }
    }
}

object Ai {
    fun summarize(c: Context, log: String): String? {
        val key = P.s(c, "ai_key").trim()
        if (key.isBlank()) return null
        try {
            val prompt = "Below is my automatic daily activity log from my phone. Write a short summary in simple English " +
                "(max 8 lines): where my time went, who I interacted with most (family, friends, official), " +
                "anything that needs follow-up, and one suggestion for tomorrow.\n\n" + log
            val msg = JSONObject().put("role", "user").put("content", prompt)
            val body = JSONObject()
                .put("model", "claude-sonnet-5")
                .put("max_tokens", 600)
                .put("messages", JSONArray().put(msg))
                .toString()
            val h = HashMap<String, String>()
            h["x-api-key"] = key
            h["anthropic-version"] = "2023-06-01"
            h["content-type"] = "application/json"
            val r = Net.call("POST", "https://api.anthropic.com/v1/messages", h, body)
            if (r.first !in 200..299) return null
            return JSONObject(r.second).getJSONArray("content").getJSONObject(0).optString("text")
        } catch (e: Exception) {
            return null
        }
    }
}

/* ---------------- place naming ---------------- */
object Geo {
    @Suppress("DEPRECATION")
    fun name(c: Context, lat: Double, lng: Double): Pair<String, String> {
        val db = Db.get(c)
        val cur = db.rawQuery("SELECT name,kind,lat,lng FROM places", null)
        var bestName: String? = null
        var bestKind = "other"
        var bd = 1e9
        while (cur.moveToNext()) {
            val d = U.dist(lat, lng, cur.getDouble(2), cur.getDouble(3))
            if (d < 150 && d < bd) {
                bd = d
                bestName = cur.getString(0)
                bestKind = cur.getString(1) ?: "other"
            }
        }
        cur.close()
        if (bestName != null) return Pair(bestName, bestKind)

        val k = String.format(Locale.US, "%.3f,%.3f", lat, lng)
        val cc = db.rawQuery("SELECT name FROM geo_cache WHERE k=?", arrayOf(k))
        var nm: String? = null
        if (cc.moveToFirst()) nm = cc.getString(0)
        cc.close()
        if (nm == null) {
            nm = try {
                if (Geocoder.isPresent()) {
                    val l = Geocoder(c, Locale.getDefault()).getFromLocation(lat, lng, 1)
                    if (l != null && l.isNotEmpty()) {
                        val a = l[0]
                        val first = a.subLocality ?: a.thoroughfare ?: a.featureName
                        listOfNotNull(first, a.locality).distinct().joinToString(", ")
                    } else null
                } else null
            } catch (e: Exception) {
                null
            }
            if (nm != null && nm.isNotBlank()) {
                db.execSQL("INSERT OR REPLACE INTO geo_cache(k,name) VALUES(?,?)", arrayOf(k, nm))
            }
        }
        val out = if (nm != null && nm.isNotBlank()) nm else String.format(Locale.US, "Place %.4f,%.4f", lat, lng)
        return Pair(out, "other")
    }
}

/* ---------------- steps ---------------- */
object Steps {
    fun record(c: Context, v: Long) {
        val d = U.today()
        val sp = P.sp(c)
        val ed = sp.edit()
        if (!sp.contains("sb_$d")) ed.putLong("sb_$d", v)
        ed.putLong("sl_$d", v)
        ed.apply()
    }

    fun get(c: Context, d: String): Int {
        val sp = P.sp(c)
        val last = sp.getLong("sl_$d", -1L)
        if (last < 0) return 0
        var base = sp.getLong("sb_$d", 0L)
        if (last < base) base = 0
        return (last - base).toInt()
    }
}

/* ---------------- background sync: calls + app usage ---------------- */
object Sync {
    fun run(c: Context, upload: Boolean) {
        try { importCalls(c) } catch (e: Exception) {}
        try { snapUsage(c) } catch (e: Exception) {}
        if (upload) {
            try {
                val day = U.today()
                val b = Report.build(c, day)
                Cloud.put(c, day, b.json)
            } catch (e: Exception) {}
        }
    }

    private fun importCalls(c: Context) {
        if (c.checkSelfPermission(android.Manifest.permission.READ_CALL_LOG) != android.content.pm.PackageManager.PERMISSION_GRANTED) return
        var last = P.l(c, "calls_last", 0L)
        if (last == 0L) last = System.currentTimeMillis() - 7L * 86400000L
        val cur = c.contentResolver.query(
            CallLog.Calls.CONTENT_URI,
            arrayOf(CallLog.Calls.NUMBER, CallLog.Calls.CACHED_NAME, CallLog.Calls.DATE, CallLog.Calls.DURATION, CallLog.Calls.TYPE),
            CallLog.Calls.DATE + ">?",
            arrayOf(last.toString()),
            CallLog.Calls.DATE + " ASC"
        ) ?: return
        val db = Db.get(c)
        var maxT = last
        db.beginTransaction()
        try {
            while (cur.moveToNext()) {
                val number = cur.getString(0) ?: ""
                val name = cur.getString(1) ?: ""
                val t = cur.getLong(2)
                val dur = cur.getLong(3)
                val type = cur.getInt(4)
                val grp = Classify.forName(c, name) ?: "Other"
                val cv = ContentValues()
                cv.put("t", t)
                cv.put("number", number)
                cv.put("name", name)
                cv.put("dur", dur)
                cv.put("type", type)
                cv.put("grp", grp)
                db.insertWithOnConflict("calls", null, cv, SQLiteDatabase.CONFLICT_IGNORE)
                if (t > maxT) maxT = t
            }
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
            cur.close()
        }
        P.putL(c, "calls_last", maxT)
    }

    fun hasUsageAccess(c: Context): Boolean {
        val ops = c.getSystemService(Context.APP_OPS_SERVICE) as android.app.AppOpsManager
        return ops.unsafeCheckOpNoThrow(
            android.app.AppOpsManager.OPSTR_GET_USAGE_STATS,
            android.os.Process.myUid(),
            c.packageName
        ) == android.app.AppOpsManager.MODE_ALLOWED
    }

    private fun snapUsage(c: Context) {
        if (!hasUsageAccess(c)) return
        val um = c.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val now = System.currentTimeMillis()
        val day = U.day(now)
        val start = U.dayStart(day)
        val ev = um.queryEvents(start, now)
        val e = UsageEvents.Event()
        val fg = HashMap<String, Long>()
        val tot = HashMap<String, Long>()
        while (ev.hasNextEvent()) {
            ev.getNextEvent(e)
            val pkg = e.packageName ?: continue
            if (e.eventType == UsageEvents.Event.ACTIVITY_RESUMED) {
                fg[pkg] = e.timeStamp
            } else if (e.eventType == UsageEvents.Event.ACTIVITY_PAUSED) {
                val st = fg.remove(pkg)
                if (st != null) tot[pkg] = (tot[pkg] ?: 0L) + (e.timeStamp - st)
            }
        }
        for ((pkg, st) in fg) tot[pkg] = (tot[pkg] ?: 0L) + (now - st)
        val skip = setOf(c.packageName, "com.sec.android.app.launcher", "com.android.systemui", "com.google.android.apps.nexuslauncher")
        val db = Db.get(c)
        val pm = c.packageManager
        db.beginTransaction()
        try {
            db.execSQL("DELETE FROM usage WHERE day=?", arrayOf(day))
            for ((pkg, ms) in tot) {
                if (ms < 60000L || skip.contains(pkg)) continue
                val label = try {
                    pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
                } catch (ex: Exception) {
                    pkg
                }
                db.execSQL("INSERT OR REPLACE INTO usage(day,pkg,app,ms) VALUES(?,?,?,?)", arrayOf(day, pkg, label, ms))
            }
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }
}

/* ---------------- the daily report ---------------- */
class Built(var text: String, var short: String, val json: JSONObject)

private class Pt(val t: Long, val lat: Double, val lng: Double)
private class Cl(var start: Long, var end: Long, var lat: Double, var lng: Double, var n: Int)
private class Stop(val name: String, val kind: String, val start: Long, val end: Long, val lat: Double, val lng: Double)

object Report {
    val GROUPS = listOf("Family", "Friends", "Official", "Other")

    fun build(c: Context, day: String): Built {
        val db = Db.get(c)
        val s = U.dayStart(day)
        val e = s + 86400000L
        val a = arrayOf(s.toString(), e.toString())
        val j = JSONObject()
        j.put("day", day)
        j.put("updated", System.currentTimeMillis())

        // ---- places and distance
        val pts = ArrayList<Pt>()
        var cur = db.rawQuery("SELECT t,lat,lng FROM loc WHERE t>=? AND t<? AND acc<=150 ORDER BY t", a)
        while (cur.moveToNext()) pts.add(Pt(cur.getLong(0), cur.getDouble(1), cur.getDouble(2)))
        cur.close()

        var km = 0.0
        for (i in 1 until pts.size) {
            val p = pts[i - 1]
            val q = pts[i]
            if (q.t - p.t > 15 * 60000L) continue
            val d = U.dist(p.lat, p.lng, q.lat, q.lng)
            if (d > 40 && d < 30000) km += d / 1000.0
        }

        val clusters = ArrayList<Cl>()
        var openCl: Cl? = null
        for (p in pts) {
            val o = openCl
            if (o == null) {
                openCl = Cl(p.t, p.t, p.lat, p.lng, 1)
                continue
            }
            val gap = p.t - o.end
            if (gap <= 30 * 60000L && U.dist(o.lat, o.lng, p.lat, p.lng) <= 120.0) {
                o.n = o.n + 1
                o.lat = o.lat + (p.lat - o.lat) / o.n
                o.lng = o.lng + (p.lng - o.lng) / o.n
                o.end = p.t
            } else {
                if (o.end - o.start >= 10 * 60000L) clusters.add(o)
                openCl = Cl(p.t, p.t, p.lat, p.lng, 1)
            }
        }
        val lastOpen = openCl
        if (lastOpen != null && lastOpen.end - lastOpen.start >= 10 * 60000L) clusters.add(lastOpen)

        val stops = ArrayList<Stop>()
        for (cl in clusters) {
            val nk = Geo.name(c, cl.lat, cl.lng)
            if (stops.isNotEmpty() && stops[stops.size - 1].name == nk.first && cl.start - stops[stops.size - 1].end < 20 * 60000L) {
                val l = stops[stops.size - 1]
                stops[stops.size - 1] = Stop(nk.first, nk.second, l.start, cl.end, l.lat, l.lng)
            } else {
                stops.add(Stop(nk.first, nk.second, cl.start, cl.end, cl.lat, cl.lng))
            }
        }
        val placesJ = JSONArray()
        var workMs = 0L
        var homeMs = 0L
        var firstWork = 0L
        var lastWork = 0L
        for (st in stops) {
            val ms = st.end - st.start
            if (st.kind == "work") {
                workMs += ms
                if (firstWork == 0L) firstWork = st.start
                lastWork = st.end
            }
            if (st.kind == "home") homeMs += ms
            placesJ.put(
                JSONObject().put("name", st.name).put("kind", st.kind).put("start", st.start)
                    .put("end", st.end).put("mins", (ms / 60000L).toInt()).put("lat", st.lat).put("lng", st.lng)
            )
        }
        j.put("places", placesJ)
        j.put("work", JSONObject().put("mins", (workMs / 60000L).toInt()).put("first", firstWork).put("last", lastWork))
        j.put("home_mins", (homeMs / 60000L).toInt())
        j.put("km", Math.round(km * 10.0) / 10.0)
        j.put("steps", Steps.get(c, day))

        // ---- calls
        val cn = HashMap<String, Int>()
        val cs = HashMap<String, Int>()
        val callList = JSONArray()
        var callTotal = 0
        var callSecs = 0
        cur = db.rawQuery("SELECT t,number,name,dur,type,grp FROM calls WHERE t>=? AND t<? ORDER BY t", a)
        while (cur.moveToNext()) {
            val g = cur.getString(5) ?: "Other"
            val dur = cur.getInt(3)
            cn[g] = (cn[g] ?: 0) + 1
            cs[g] = (cs[g] ?: 0) + dur
            callTotal++
            callSecs += dur
            val nm = cur.getString(2) ?: ""
            if (callList.length() < 40) {
                callList.put(
                    JSONObject().put("t", cur.getLong(0)).put("name", if (nm.isBlank()) (cur.getString(1) ?: "") else nm)
                        .put("grp", g).put("type", cur.getInt(4)).put("mins", dur / 60)
                )
            }
        }
        cur.close()
        val callG = JSONObject()
        for (g in GROUPS) callG.put(g, JSONObject().put("n", cn[g] ?: 0).put("mins", (cs[g] ?: 0) / 60))
        j.put("calls", JSONObject().put("total", callTotal).put("mins", callSecs / 60).put("groups", callG).put("list", callList))

        // ---- messages and notifications
        val keys = Classify.MSG.keys.joinToString(",") { "'$it'" }
        val mg = HashMap<String, Int>()
        val senders = HashMap<String, Int>()
        val senderGrp = HashMap<String, String>()
        val apps = HashMap<String, Int>()
        val recent = JSONArray()
        var msgTotal = 0
        cur = db.rawQuery("SELECT t,app,title,body,grp FROM notif WHERE t>=? AND t<? AND pkg IN ($keys) ORDER BY t", a)
        while (cur.moveToNext()) {
            val g = cur.getString(4) ?: "Other"
            val who = cur.getString(2) ?: ""
            val app = cur.getString(1) ?: ""
            mg[g] = (mg[g] ?: 0) + 1
            senders[who] = (senders[who] ?: 0) + 1
            senderGrp[who] = g
            apps[app] = (apps[app] ?: 0) + 1
            msgTotal++
            recent.put(
                JSONObject().put("t", cur.getLong(0)).put("app", app).put("who", who).put("grp", g)
                    .put("text", (cur.getString(3) ?: "").take(160))
            )
        }
        cur.close()
        val recentTrim = JSONArray()
        val from = if (recent.length() > 40) recent.length() - 40 else 0
        for (i in from until recent.length()) recentTrim.put(recent.get(i))
        val msgG = JSONObject()
        for (g in GROUPS) msgG.put(g, mg[g] ?: 0)
        val sendersJ = JSONArray()
        for (en in senders.entries.sortedByDescending { it.value }.take(10)) {
            sendersJ.put(JSONObject().put("name", en.key).put("grp", senderGrp[en.key] ?: "Other").put("n", en.value))
        }
        val appsJ = JSONArray()
        for (en in apps.entries.sortedByDescending { it.value }) appsJ.put(JSONObject().put("app", en.key).put("n", en.value))
        cur = db.rawQuery("SELECT COUNT(*) FROM notif WHERE t>=? AND t<?", a)
        var allNotif = 0
        if (cur.moveToFirst()) allNotif = cur.getInt(0)
        cur.close()
        j.put(
            "msgs",
            JSONObject().put("total", msgTotal).put("groups", msgG).put("senders", sendersJ).put("apps", appsJ)
                .put("recent", recentTrim).put("all_notifications", allNotif)
        )

        // ---- conversations (speech to text)
        val tg = HashMap<String, Int>()
        val lines = JSONArray()
        var words = 0
        var segs = 0
        cur = db.rawQuery("SELECT t,body,grp FROM talk WHERE t>=? AND t<? ORDER BY t", a)
        while (cur.moveToNext()) {
            val g = cur.getString(2) ?: "Other"
            val body = cur.getString(1) ?: ""
            tg[g] = (tg[g] ?: 0) + 1
            segs++
            words += body.split(" ").size
            if (lines.length() < 40) lines.put(JSONObject().put("t", cur.getLong(0)).put("grp", g).put("text", body.take(220)))
        }
        cur.close()
        val talkG = JSONObject()
        for (g in GROUPS) talkG.put(g, tg[g] ?: 0)
        j.put("talk", JSONObject().put("segments", segs).put("words", words).put("groups", talkG).put("lines", lines))

        // ---- app usage
        val top = JSONArray()
        var usageMs = 0L
        cur = db.rawQuery("SELECT app,ms FROM usage WHERE day=? ORDER BY ms DESC", arrayOf(day))
        var count = 0
        while (cur.moveToNext()) {
            usageMs += cur.getLong(1)
            if (count < 10) top.put(JSONObject().put("app", cur.getString(0) ?: "").put("mins", (cur.getLong(1) / 60000L).toInt()))
            count++
        }
        cur.close()
        j.put("usage", JSONObject().put("total_mins", (usageMs / 60000L).toInt()).put("top", top))

        // ---- photos
        cur = db.rawQuery("SELECT COUNT(*) FROM photos WHERE t>=? AND t<?", a)
        var photos = 0
        if (cur.moveToFirst()) photos = cur.getInt(0)
        cur.close()
        j.put("photos", photos)
        j.put("ai", "")

        return Built(toText(j, true), toText(j, false), j)
    }

    private fun groupLine(g: JSONObject): String {
        val parts = ArrayList<String>()
        for (k in GROUPS) {
            val v = g.opt(k)
            val n = if (v is JSONObject) v.optInt("n") else g.optInt(k)
            if (n > 0) parts.add("$k $n")
        }
        return if (parts.isEmpty()) "none" else parts.joinToString(", ")
    }

    fun toText(j: JSONObject, full: Boolean): String {
        val sb = StringBuilder()
        sb.append("Day Log - ").append(j.optString("day")).append("\n\n")

        val work = j.optJSONObject("work")
        val wm = work?.optInt("mins") ?: 0
        if (wm > 0) {
            sb.append("Work: ").append(U.dur(wm)).append(" at work place")
            val f = work?.optLong("first") ?: 0L
            val l = work?.optLong("last") ?: 0L
            if (f > 0) sb.append(" (").append(U.hm(f)).append(" to ").append(U.hm(l)).append(")")
            sb.append("\n")
        }
        val us = j.optJSONObject("usage")
        if ((us?.optInt("total_mins") ?: 0) > 0) sb.append("Phone screen time: ").append(U.dur(us?.optInt("total_mins") ?: 0)).append("\n")
        sb.append("Steps: ").append(j.optInt("steps")).append(", travelled about ").append(j.optDouble("km")).append(" km\n\n")

        sb.append("Places:\n")
        val pl = j.optJSONArray("places") ?: JSONArray()
        if (pl.length() == 0) sb.append("  no stops recorded yet\n")
        val maxP = if (full) 30 else 10
        for (i in 0 until minOf(pl.length(), maxP)) {
            val p = pl.getJSONObject(i)
            sb.append("  ").append(U.hm(p.optLong("start"))).append(" - ").append(U.hm(p.optLong("end")))
                .append("  ").append(p.optString("name")).append(" (").append(U.dur(p.optInt("mins"))).append(")\n")
        }

        val calls = j.optJSONObject("calls")
        sb.append("\nCalls: ").append(calls?.optInt("total") ?: 0).append(" (").append(U.dur(calls?.optInt("mins") ?: 0)).append(")")
        val cg = calls?.optJSONObject("groups")
        if (cg != null) sb.append(" - ").append(groupLine(cg))
        sb.append("\n")

        val msgs = j.optJSONObject("msgs")
        sb.append("Messages: ").append(msgs?.optInt("total") ?: 0)
        val mgj = msgs?.optJSONObject("groups")
        if (mgj != null) sb.append(" - ").append(groupLine(mgj))
        sb.append("\n")
        val sn = msgs?.optJSONArray("senders")
        if (sn != null && sn.length() > 0) {
            sb.append("  Most active: ")
            val names = ArrayList<String>()
            for (i in 0 until minOf(sn.length(), 5)) {
                val o = sn.getJSONObject(i)
                names.add(o.optString("name") + " (" + o.optString("grp") + ", " + o.optInt("n") + ")")
            }
            sb.append(names.joinToString(", ")).append("\n")
        }

        val talk = j.optJSONObject("talk")
        if ((talk?.optInt("segments") ?: 0) > 0) {
            sb.append("Conversations heard: ").append(talk?.optInt("segments") ?: 0).append(" parts - ")
            val tgj = talk?.optJSONObject("groups")
            if (tgj != null) sb.append(groupLine(tgj))
            sb.append("\n")
        }
        val top = us?.optJSONArray("top")
        if (top != null && top.length() > 0) {
            sb.append("Top apps: ")
            val names = ArrayList<String>()
            for (i in 0 until minOf(top.length(), if (full) 8 else 4)) {
                val o = top.getJSONObject(i)
                names.add(o.optString("app") + " " + U.dur(o.optInt("mins")))
            }
            sb.append(names.joinToString(", ")).append("\n")
        }
        if (j.optInt("photos") > 0) sb.append("Photos captured: ").append(j.optInt("photos")).append("\n")

        // simple insights
        val totals = HashMap<String, Int>()
        for (g in listOf("Family", "Friends", "Official")) {
            var n = 0
            n += calls?.optJSONObject("groups")?.optJSONObject(g)?.optInt("n") ?: 0
            n += msgs?.optJSONObject("groups")?.optInt(g) ?: 0
            n += talk?.optJSONObject("groups")?.optInt(g) ?: 0
            totals[g] = n
        }
        val top1 = totals.entries.maxByOrNull { it.value }
        if (top1 != null && top1.value > 0) sb.append("\nMost interaction today: ").append(top1.key).append(" (").append(top1.value).append(")\n")

        if (full) {
            val rec = msgs?.optJSONArray("recent")
            if (rec != null && rec.length() > 0) {
                sb.append("\nRecent messages:\n")
                for (i in maxOf(0, rec.length() - 12) until rec.length()) {
                    val o = rec.getJSONObject(i)
                    sb.append("  ").append(U.hm(o.optLong("t"))).append(" ").append(o.optString("who")).append(" [").append(o.optString("grp")).append("]: ")
                        .append(o.optString("text").take(80)).append("\n")
                }
            }
            val ln = talk?.optJSONArray("lines")
            if (ln != null && ln.length() > 0) {
                sb.append("\nConversation notes:\n")
                for (i in 0 until minOf(ln.length(), 12)) {
                    val o = ln.getJSONObject(i)
                    sb.append("  ").append(U.hm(o.optLong("t"))).append(" [").append(o.optString("grp")).append("]: ")
                        .append(o.optString("text").take(100)).append("\n")
                }
            }
        }
        val ai = j.optString("ai")
        if (ai.isNotBlank()) sb.append("\nAI summary:\n").append(ai).append("\n")
        return sb.toString().trim()
    }
}

/* ---------------- notifications for the report ---------------- */
object Notif {
    fun channels(c: Context) {
        val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("track", "Tracking", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel("reports", "Daily report", NotificationManager.IMPORTANCE_DEFAULT))
    }

    fun persistent(c: Context, title: String, text: String): Notification {
        val pi = PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        return Notification.Builder(c, "track")
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setContentTitle(title)
            .setContentText(text)
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
    }

    fun report(c: Context, b: Built) {
        val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val wa = PendingIntent.getActivity(
            c, 1,
            Intent(Intent.ACTION_VIEW, Uri.parse(Wa.url(c, b.short.take(1800)))),
            PendingIntent.FLAG_IMMUTABLE
        )
        val open = PendingIntent.getActivity(c, 2, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val action = Notification.Action.Builder(
            Icon.createWithResource(c, android.R.drawable.ic_menu_send), "Send to WhatsApp", wa
        ).build()
        val n = Notification.Builder(c, "reports")
            .setSmallIcon(android.R.drawable.ic_menu_agenda)
            .setContentTitle("Your daily report is ready")
            .setContentText("Tap to open, or send it to WhatsApp")
            .setStyle(Notification.BigTextStyle().bigText(b.short.take(1500)))
            .setContentIntent(open)
            .addAction(action)
            .setAutoCancel(true)
            .build()
        nm.notify(100, n)
    }
}

object Sched {
    fun daily(c: Context) {
        val parts = P.s(c, "report_time", "21:30").split(":")
        val h = parts.getOrNull(0)?.trim()?.toIntOrNull() ?: 21
        val m = parts.getOrNull(1)?.trim()?.toIntOrNull() ?: 30
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, h)
        cal.set(Calendar.MINUTE, m)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        if (cal.timeInMillis <= System.currentTimeMillis() + 1000L) cal.add(Calendar.DAY_OF_YEAR, 1)
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = PendingIntent.getBroadcast(
            c, 7, Intent(c, ReportReceiver::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
    }
}

object Deliver {
    fun dailyReport(c: Context) {
        Sync.run(c, false)
        val day = U.today()
        val b = Report.build(c, day)
        val ai = Ai.summarize(c, b.short)
        if (ai != null && ai.isNotBlank()) {
            b.json.put("ai", ai)
            b.text = b.text + "\n\nAI summary:\n" + ai
            b.short = b.short + "\n\nAI summary:\n" + ai
        }
        P.put(c, "last_report", b.text)
        Cloud.put(c, day, b.json)
        Wa.auto(c, b.short)
        Notif.report(c, b)
    }
}
