Day Log - automatic daily tracker (Android)
Files:
  app/                 Android app source (Kotlin)
  docs/index.html      Web dashboard (GitHub Pages)
  supabase-setup.sql   Database setup for the dashboard
Build: push this zip to GitHub as daylog-project.zip with .github/workflows/build.yml
